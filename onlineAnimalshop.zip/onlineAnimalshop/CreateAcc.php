<?php
include('Masterpage.php');
?>
<!DOCTYPE html>
<html lang="en">


<head>
<title>Pet Cave||Create Account</title>
</head>

<body>
	<br><br><br>
  <header>
  	<div class="container">
    <div class="container center-div shadow">
      <h1 style="text-align: center;">Create New Account Here</h1>
      <div class="container row d-flex flex-row justify-content-center mb-5">
        <div class="admin-form shadow p-2">
          <form action="DB_CreateAcc.php" method="POST">
            <div class="form-group" style="width: 700px;">
              <label>Name</label>
              <input type="text" name="c_name" value="" class="form-control" placeholder="Enter Your Name Here" autocomplete="off" required="">
            </div>
            <div class="form-group" style="width: 700px;">
              <label>Email</label>
              <input type="email" name="c_mail" value="" class="form-control" placeholder="Enter Your Email Here" autocomplete="off" required="">
            </div>
            <div class="form-group" style="width: 700px;">
              <label>Mobile Phone Number</label>
              <input type="text" name="c_phone" value="" class="form-control" placeholder="Enter Your Mobile Number Here" autocomplete="off" required="">
            </div>
            <div class="form-group" style="width: 700px;">
              <label>NID</label>
              <input type="text" name="c_nid" value="" class="form-control" placeholder="Enter Your NID Number Here" autocomplete="off" required="">
            </div>
            <div class="form-group" style="width: 700px;">
              <label>Age</label>
              <input type="text" name="c_age" value="" class="form-control" placeholder="Enter Your Age Here" autocomplete="off" required="">
            </div>
            <div class="form-group" style="width: 700px;">
              <label>Address</label>
              <input type="text" name="c_address" value="" class="form-control" placeholder="Enter Your Address Here" autocomplete="off" required="">
            </div>
            <div class="form-group" style="width: 700px;">
              <label>Password</label>
              <input type="text" name="c_password" value="" class="form-control" placeholder="Enter Your Password Here" autocomplete="off"  required="">
            </div>
            <center>
            	<input type="Submit" class="btn btn-success" name="submit" value="Create Now">
            </center>
          </form>
          <br><br><br>
    	</div>
	</div>
	</div>
  </header>
<footer>
        <div class="footer-main">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-12 col-sm-12">
                        <div class="footer-widget">
                            <h4>About BiTechX Alpha</h4>
                            <p>We are so much honest to provide service to our client. We try our best to give the product's best quality.
                                </p>
                            <ul>
                                <li><a href="#"><i class="fab fa-facebook" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fab fa-twitter" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fab fa-linkedin" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fab fa-google-plus" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fa fa-rss" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fab fa-pinterest-p" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fab fa-whatsapp" aria-hidden="true"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12 col-sm-12">
                        <div class="footer-link">
                            <h4>Information</h4>
                            <ul>
                                <li><a href="#">About Us</a></li>
                                <li><a href="#">Customer Service</a></li>
                                <li><a href="#">Our Sitemap</a></li>
                                <li><a href="#">Terms &amp; Conditions</a></li>
                                <li><a href="#">Privacy Policy</a></li>
                                <li><a href="#">Delivery Information</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12 col-sm-12">
                        <div class="footer-link-contact">
                            <h4>Contact Us</h4>
                            <ul>
                                <li>
                                    <p><i class="fas fa-map-marker-alt"></i>Address: 102-Shukrabad, Mirpur Road<br>, Dhaka-1207<br></p>
                                </li>
                                <li>
                                    <p><i class="fas fa-phone-square"></i>Phone: <a href="tel:+88 000 00 0000000">+88 000 00 0000000</a></p>
                                </li>
                                <li>
                                    <p><i class="fas fa-envelope"></i>Email: <a href="mailto:contactinfo@gmail.com">contactherebro@gmail.com</a></p>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    
    <a href="#" id="back-to-top" title="Back to top" style="display: none;">&uarr;</a>


    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

    <script src="js/jquery.superslides.min.js"></script>
    <script src="js/bootstrap-select.js"></script>
    <script src="js/inewsticker.js"></script>
    <script src="js/bootsnav.js."></script>
    <script src="js/images-loded.min.js"></script>
    <script src="js/isotope.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/baguetteBox.min.js"></script>
    <script src="js/form-validator.min.js"></script>
    <script src="js/contact-form-script.js"></script>
    <script src="js/custom.js"></script>
</body>

</html>