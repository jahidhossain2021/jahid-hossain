-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 19, 2021 at 04:23 PM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pet_cave`
--

-- --------------------------------------------------------

--
-- Table structure for table `birds`
--

CREATE TABLE `birds` (
  `b_id` int(11) NOT NULL,
  `b_name` varchar(200) NOT NULL,
  `age` varchar(50) NOT NULL,
  `b_breed` varchar(50) NOT NULL,
  `price` varchar(50) NOT NULL,
  `shop` varchar(200) NOT NULL,
  `b_image` varchar(250) NOT NULL,
  `r_mail` varchar(200) NOT NULL,
  `r_phone` varchar(50) NOT NULL,
  `pk_date` varchar(50) NOT NULL,
  `book` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `birds`
--

INSERT INTO `birds` (`b_id`, `b_name`, `age`, `b_breed`, `price`, `shop`, `b_image`, `r_mail`, `r_phone`, `pk_date`, `book`) VALUES
(1, 'Coctail', '1 Month', 'Pure', '3000', 'Pet Cave', 'img1216579186.jpg', 'smshuvo1612@gmail.com', '01762128000', '2020-12-12', '1');

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

CREATE TABLE `client` (
  `id` int(11) NOT NULL,
  `c_name` varchar(200) NOT NULL,
  `c_mail` varchar(200) NOT NULL,
  `c_phone` varchar(200) NOT NULL,
  `c_nid` varchar(200) NOT NULL,
  `c_age` varchar(200) NOT NULL,
  `c_address` varchar(250) NOT NULL,
  `c_password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`id`, `c_name`, `c_mail`, `c_phone`, `c_nid`, `c_age`, `c_address`, `c_password`) VALUES
(1, 'Sagar Barai', 'sagar35-1561@diu.edu.bd', '014567890', '123456788098745', '23', 'H-78, 102/Sukrabad, Dhanmondi-32, Dhaka', 'Sagar Barai'),
(2, 'Bappy', 'bappy@gmail.com', '01705645150', '3455987654489', '23', 'Dhaka', 'bappy');

-- --------------------------------------------------------

--
-- Table structure for table `fishes`
--

CREATE TABLE `fishes` (
  `f_id` int(11) NOT NULL,
  `f_name` varchar(200) NOT NULL,
  `age` varchar(50) NOT NULL,
  `f_breed` varchar(50) NOT NULL,
  `price` varchar(50) NOT NULL,
  `shop` varchar(200) NOT NULL,
  `f_image` varchar(250) NOT NULL,
  `r_mail` varchar(200) NOT NULL,
  `r_phone` varchar(50) NOT NULL,
  `pk_date` varchar(50) NOT NULL,
  `book` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `fishes`
--

INSERT INTO `fishes` (`f_id`, `f_name`, `age`, `f_breed`, `price`, `shop`, `f_image`, `r_mail`, `r_phone`, `pk_date`, `book`) VALUES
(1, 'Gold fish', '15 Days', 'Pure', '200', 'Pet Cave', 'img1216504573.jpeg', 'smshuvo1612@gmail.com', '01762128000', '2020-12-25', '1');

-- --------------------------------------------------------

--
-- Table structure for table `kittens`
--

CREATE TABLE `kittens` (
  `k_id` int(11) NOT NULL,
  `k_name` varchar(200) NOT NULL,
  `age` varchar(50) NOT NULL,
  `k_breed` varchar(50) NOT NULL,
  `price` varchar(50) NOT NULL,
  `shop` varchar(200) NOT NULL,
  `k_image` varchar(250) NOT NULL,
  `r_mail` varchar(200) NOT NULL,
  `r_phone` varchar(50) NOT NULL,
  `pk_date` varchar(50) NOT NULL,
  `book` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `kittens`
--

INSERT INTO `kittens` (`k_id`, `k_name`, `age`, `k_breed`, `price`, `shop`, `k_image`, `r_mail`, `r_phone`, `pk_date`, `book`) VALUES
(1, 'Garfield', '2 month', 'Pure', '20000', 'Pet Cave', 'img1216468830.jpg', '', '', '', '1');

-- --------------------------------------------------------

--
-- Table structure for table `puppies`
--

CREATE TABLE `puppies` (
  `p_id` int(11) NOT NULL,
  `p_name` varchar(200) NOT NULL,
  `age` varchar(50) NOT NULL,
  `p_breed` varchar(50) NOT NULL,
  `price` varchar(50) NOT NULL,
  `shop` varchar(200) NOT NULL,
  `p_image` varchar(250) NOT NULL,
  `r_mail` varchar(200) NOT NULL,
  `r_phone` varchar(50) NOT NULL,
  `pk_date` varchar(50) NOT NULL,
  `book` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `puppies`
--

INSERT INTO `puppies` (`p_id`, `p_name`, `age`, `p_breed`, `price`, `shop`, `p_image`, `r_mail`, `r_phone`, `pk_date`, `book`) VALUES
(1, 'Huskey', '2 Months', 'Pure Breed', '75000', 'Pet Cave', 'img1106458950.jpeg', '', '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `birds`
--
ALTER TABLE `birds`
  ADD PRIMARY KEY (`b_id`);

--
-- Indexes for table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fishes`
--
ALTER TABLE `fishes`
  ADD PRIMARY KEY (`f_id`);

--
-- Indexes for table `kittens`
--
ALTER TABLE `kittens`
  ADD PRIMARY KEY (`k_id`);

--
-- Indexes for table `puppies`
--
ALTER TABLE `puppies`
  ADD PRIMARY KEY (`p_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `birds`
--
ALTER TABLE `birds`
  MODIFY `b_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `client`
--
ALTER TABLE `client`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `fishes`
--
ALTER TABLE `fishes`
  MODIFY `f_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `kittens`
--
ALTER TABLE `kittens`
  MODIFY `k_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `puppies`
--
ALTER TABLE `puppies`
  MODIFY `p_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
