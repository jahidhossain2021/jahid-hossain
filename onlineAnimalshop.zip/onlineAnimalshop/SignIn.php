<?php
include('Masterpage.php');
?>
<!DOCTYPE html>
<html lang="en">


<head>
<title>Pet Cave||Create Account</title>
</head>

<body>
	<br><br><br>
  	<div class="container">
        <div class="container center-div shadow"><br><br>
          <h1 style="text-align: center;">Sign In </h1>
          <div class="container row d-flex flex-row justify-content-center mb-5">
                <div class="admin-form shadow p-2">
                    <form action="DB_SignIn.php" method="POST">
                  	     <div class="form-group">
                  			<label for="exampleInputEmail1">Type Of User</label>
                  			<select class="custom-select" name="user">
                                <option selected>Please Select Catagory</option>
                                <option value="client">Client</option>
                            </select>
                  		</div>
                        <div class="form-group" style="width: 700px;">
                          <label>Email or Admin ID</label>
                          <input type="text" name="c_mail" value="" class="form-control" placeholder="Enter Your Email or Admin ID Here" autocomplete="off">
                        </div>
                        <div class="form-group" style="width: 700px;">
                          <label>Password</label>
                          <input type="password" name="c_password" value="" class="form-control" placeholder="Enter Your Password Here" autocomplete="off">
                        </div>
                        <div class="form-group" style="width: 700px;">
                        	<small id="passwordHelpInline" class="text-muted" style="padding: 20px; font-color: black; text-align: center;">Don't have account..??
                        		<a href="CreateAcc.php">Create account here..</a> 
            				</small>
                        </div>
                        <center>
                        	<input type="Submit" class="btn btn-danger" name="submit" value="Sign In">
                        </center>
                    </form>
        	   </div>
            </div>
            <br>
        </div>
    </div>
    <br><br><br>
<footer>
        <div class="footer-main">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-12 col-sm-12">
                        <div class="footer-widget">
                            <h4>About BiTechX Alpha</h4>
                            <p>We are so much honest to provide service to our client. We try our best to give the product's best quality.
                                </p>
                            <ul>
                                <li><a href="#"><i class="fab fa-facebook" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fab fa-twitter" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fab fa-linkedin" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fab fa-google-plus" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fa fa-rss" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fab fa-pinterest-p" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fab fa-whatsapp" aria-hidden="true"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12 col-sm-12">
                        <div class="footer-link">
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12 col-sm-12">
                        <div class="footer-link-contact">
                            <h4>Contact Us</h4>
                            <ul>
                                <li>
                                    <p><i class="fas fa-map-marker-alt"></i>Address: 102-Shukrabad, Mirpur Road<br>, Dhaka-1207<br></p>
                                </li>
                                <li>
                                    <p><i class="fas fa-phone-square"></i>Phone: <a href="tel:+88 000 00 0000000">+88 000 00 0000000</a></p>
                                </li>
                                <li>
                                    <p><i class="fas fa-envelope"></i>Email: <a href="mailto:contactinfo@gmail.com">contactherebro@gmail.com</a></p>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    
    <a href="#" id="back-to-top" title="Back to top" style="display: none;">&uarr;</a>


    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

    <script src="js/jquery.superslides.min.js"></script>
    <script src="js/bootstrap-select.js"></script>
    <script src="js/inewsticker.js"></script>
    <script src="js/bootsnav.js."></script>
    <script src="js/images-loded.min.js"></script>
    <script src="js/isotope.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/baguetteBox.min.js"></script>
    <script src="js/form-validator.min.js"></script>
    <script src="js/contact-form-script.js"></script>
    <script src="js/custom.js"></script>
</body>

</html>