<?php
include('CLientMain.php');
?>
<!DOCTYPE html>
<html lang="en">


<head>
<title>Pet Cave||Client Home</title>
</head>

<body>
	<hr>

    <div id="slides-shop" class="cover-slides">
        <ul class="slides-container">
            <li class="text-left">
                <img src="images/banner-01.jpg" alt="">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <h1 class="m-b-20"><strong>Welcome To <br> Pet Cave|| Client Section</strong></h1>
                            <p class="m-b-40">Hi..! Dear Client Please Click The Button Given For Adding New Services Or Upcoming New Pets Basic Information To This Business</p>
                            <p><a class="btn hvr-hover" href="#">Add new</a></p>
                        </div>
                    </div>
                </div>
            </li>
            <li class="text-left">
                <img src="images/banner-02.jpg" alt="">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <h1 class="m-b-20"><strong>Welcome To <br> Pet Cave|| Client Section</strong></h1>
                            <p class="m-b-40">Hi..! Dear Client Please Click The Button Given For Adding New Services Or Upcoming New Pets Basic Information To This Business</p>
                            <p><a class="btn hvr-hover" href="#">Add new</a></p>
                        </div>
                    </div>
                </div>
            </li>
            <li class="text-left">
                <img src="images/banner-03.jpg" alt="">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <h1 class="m-b-20"><strong>Welcome To <br> Pet Cave|| Client Section</strong></h1>
                            <p class="m-b-40">Hi..! Dear Client Please Click The Button Given For Adding New Services Or Upcoming New Pets Basic Information To This Business</p>
                            <p><a class="btn hvr-hover" href="#">Add new</a></p>
                        </div>
                    </div>
                </div>
            </li>
            <li class="text-left">
                <img src="images/banner-04.jpg" alt="">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <h1 class="m-b-20"><strong>Welcome To <br> Pet Cave|| Client Section</strong></h1>
                            <p class="m-b-40">Hi..! Dear Client Please Click The Button Given For Adding New Services Or Upcoming New Pets Basic Information To This Business</p>
                            <p><a class="btn hvr-hover" href="#">Add new</a></p>
                        </div>
                    </div>
                </div>
            </li>
        </ul>
        <div class="slides-navigation">
            <a href="#" class="next"><i class="fa fa-angle-right" aria-hidden="true"></i></a>
            <a href="#" class="prev"><i class="fa fa-angle-left" aria-hidden="true"></i></a>
        </div>
    </div><br>
    <hr>
<footer>
        <div class="footer-main">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-12 col-sm-12">
                        <div class="footer-widget">
                            <h4>About BiTechX Alpha</h4>
                            <p>We are so much honest to provide service to our client. We try our best to give the product's best quality.
                                </p>
                            <ul>
                                <li><a href="#"><i class="fab fa-facebook" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fab fa-twitter" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fab fa-linkedin" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fab fa-google-plus" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fa fa-rss" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fab fa-pinterest-p" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fab fa-whatsapp" aria-hidden="true"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12 col-sm-12">
                        <div class="footer-link">
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12 col-sm-12">
                        <div class="footer-link-contact">
                            <h4>Contact Us</h4>
                            <ul>
                                <li>
                                    <p><i class="fas fa-map-marker-alt"></i>Address: 102-Shukrabad, Mirpur Road<br>, Dhaka-1207<br></p>
                                </li>
                                <li>
                                    <p><i class="fas fa-phone-square"></i>Phone: <a href="tel:+88 000 00 0000000">+88 000 00 0000000</a></p>
                                </li>
                                <li>
                                    <p><i class="fas fa-envelope"></i>Email: <a href="mailto:contactinfo@gmail.com">contactherebro@gmail.com</a></p>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    
    <a href="#" id="back-to-top" title="Back to top" style="display: none;">&uarr;</a>


    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

    <script src="js/jquery.superslides.min.js"></script>
    <script src="js/bootstrap-select.js"></script>
    <script src="js/inewsticker.js"></script>
    <script src="js/bootsnav.js."></script>
    <script src="js/images-loded.min.js"></script>
    <script src="js/isotope.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/baguetteBox.min.js"></script>
    <script src="js/form-validator.min.js"></script>
    <script src="js/contact-form-script.js"></script>
    <script src="js/custom.js"></script>
</body>

</html>