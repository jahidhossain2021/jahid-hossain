<!DOCTYPE html>
<html lang="en">


<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">


    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">
<!-- 

    <link rel="apple-touch-icon" href="images/favicon.jpg">

 -->
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <link rel="stylesheet" href="css/style.css">

    <link rel="stylesheet" href="css/responsive.css">

    <link rel="stylesheet" href="css/custom.css">


</head>

<body>

    <div class="main-top">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <!-- -->
                    <div class="right-phone-box">
                        <p>Call US :- <a href="#"> +88 00 0000 00000</a></p>
                    </div>
                    <div class="our-link">
                        <ul>
                            <li><a href="SignIn.php">Sign In</a></li>
                            <!-- <li><a href="#">Main Branch</a></li> -->
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
            </div>
        </div>
    </div>
    <header class="main-header">

        <nav class="navbar navbar-expand-lg navbar-light bg-light navbar-default bootsnav">
            <div class="container">

                <div class="navbar-header">
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-menu" aria-controls="navbars-rs-food" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                    <a class="navbar-brand" href="index.php"><img src="images/logo.png" class="logo" alt="" style=" height: 100px; width: 100px;"></a>
                </div>

                <div class="collapse navbar-collapse" id="navbar-menu">
                    <ul class="nav navbar-nav ml-auto" data-in="fadeInDown" data-out="fadeOutUp">
                        <li class="nav-item active"><a class="nav-link" href="index.php">Home</a></li>
<!--                         <li class="nav-item"><a class="nav-link" href="">Show Rooms</a></li>
                        <li class="nav-item"><a class="nav-link" href="">Doctor's Information</a></li>
                        <li class="dropdown megamenu-fw">
                        <a href="" class="nav-link dropdown v" data-toggle="dropdown">Pets</a>
                            <ul class="dropdown-menu megamenu-content " role="menu">
                                <li>
                                    <div class="row">
                                        <div class="col">
                                            <h3 class="title"><b>Animals</b></h3>
                                            <ul class="menu-col">
                                                <li><a href="Puppies.php">Puppies</a></li>
                                                <li><a href="Kittens.php">Kittens</a></li>
                                            </ul>
                                        </div>
                                        <div class="col">
                                            <h3 class="title"><b>Others</b></h3>
                                            <ul class="menu-col">
                                                <li><a href="">Fish</a></li>
                                                <li><a href="">Birds</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </li> -->
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    
    <a href="#" id="back-to-top" title="Back to top" style="display: none;">&uarr;</a>


    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

    <script src="js/jquery.superslides.min.js"></script>
    <script src="js/bootstrap-select.js"></script>
    <script src="js/inewsticker.js"></script>
    <script src="js/bootsnav.js."></script>
    <script src="js/images-loded.min.js"></script>
    <script src="js/isotope.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/baguetteBox.min.js"></script>
    <script src="js/form-validator.min.js"></script>
    <script src="js/contact-form-script.js"></script>
    <script src="js/custom.js"></script>
</body>

</html>