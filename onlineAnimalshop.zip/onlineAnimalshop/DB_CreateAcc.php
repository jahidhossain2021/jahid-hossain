<?php 
$con=mysqli_connect("localhost","root","","pet_cave");

$c_name=$_POST['c_name'];
$c_mail=$_POST['c_mail'];
$c_phone=$_POST['c_phone'];
$c_nid=$_POST['c_nid'];
$c_age=$_POST['c_age'];
$c_address=$_POST['c_address'];
$c_password=$_POST['c_password'];


$insert="INSERT INTO client(c_name, c_mail, c_phone, c_nid, c_age, c_address, c_password) VALUES ('$c_name','$c_mail','$c_phone','$c_nid','$c_age','$c_address','$c_password')";


$sql=mysqli_query($con,$insert);

    if ($sql==true ) {
	# code...
   header('location: SignIn.php');
    }
    else{
    	    echo "Error: " . $sql . "<br>" . $con->error;
    }
?>