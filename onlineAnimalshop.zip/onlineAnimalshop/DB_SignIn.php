<?php
$con=mysqli_connect("localhost","root","","pet_cave");

$user=$_POST['user'];
$c_mail=$_POST['c_mail'];
$c_password=$_POST['c_password'];
		if ($user=="client") {
			$sql="SELECT * FROM client";
			$result = mysqli_query($con,$sql);
			while($row = mysqli_fetch_assoc($result)){
				if ($row['c_mail']==$c_mail && $row['c_password']==$c_password){
						// if($c_mail){
					 //        session_start();
					 //        $_SESSION['c_mail'] = '$c_mail';
					 //        echo 'Logged in';
						// 	header('location:User/ClientHome.php');
					 //    }
					  header('location:ClientHome.php');
				}
			}
		}
		else{

		    header('location:SignIn.php');
		}
?>